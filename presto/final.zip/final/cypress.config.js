export default {
  e2e: {
    setupNodeEvents() {
      // implement node event listeners here
    },
  },
};
